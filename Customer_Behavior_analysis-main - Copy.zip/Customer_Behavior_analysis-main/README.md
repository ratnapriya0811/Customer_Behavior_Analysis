# Customer_Behavior_analysis
Data analytics project showcasing customer behavior analysis using python, SQL, and power Bi.
